#ifndef _STACK_HPP_
#define _STACK_HPP_

#include <iostream>

using namespace std;

template <class T, int N>
class Stack
{
private:
    T *elmts;

public:
};