#include "Car.h"

int main()
{
    Car C(premium);
    C.fillingFuel(pertamax, -3000);
    C.service(pertamax, 45, 3, 3);
    return 0;
}