#include <bits/stdc++.h>
#include "Vector.hpp"
using namespace std;

int main(){
	Vector<float, 4> X;
	cin>>X;
	return 0;
}
