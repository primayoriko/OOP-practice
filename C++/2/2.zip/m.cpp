#include <iostream>
#include "test.hpp"
using namespace std;

int main(){
	Car c;  
	c.addFuel(20);    
	c.openDoor();    
	c.drive();
}
